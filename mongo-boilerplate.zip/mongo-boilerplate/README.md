# node-backend-boilerplate
A basic boilerplate for nodejs backend application with support of mysql, express
